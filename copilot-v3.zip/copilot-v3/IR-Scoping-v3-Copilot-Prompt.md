# IR Scoping v3: Copilot prompt (single file)

Attach this file to Copilot first. Everything Copilot needs to build or update `v3.html` is in here; the JSON inputs are in the `json/` folder next to it.

## For you: how to use this file

**Folder layout**

- `IR-Scoping-v3-Copilot-Prompt.md`: this file (attach it first, every time).
- `json/questionnaire/`: `lists.json`, `common-sections.json`, `closing-sections.json`, `report-checks-common.json`.
- `json/incident-types/`: one `<id>.json` per incident type.
- `json/question-files.schema.json`: the shape of those files (optional, for checking).

**To change questions in an existing v3.html (most common)**

1. Edit the JSON file(s) in `json/`.
2. In Copilot, attach this file, the edited JSON file(s) and `v3.html`, and type: **"Follow the attached prompt file. Do UPDATE."**

**To build v3.html from scratch**

1. Attach this file and type: **"Follow the attached prompt file. Do STEP 01."** Save the returned `v3.html`.
2. For each next step, attach this file plus what the table below lists, and type: **"Do STEP 02A."** (then 02B, 03 and so on).
3. Paste each returned code block directly under its marker in `v3.html` (for example under `// @@JS-DB`); keep the marker line. "REPLACE FUNCTION x" means swap the whole function.
4. After each step, open `v3.html` in Chrome or Edge and run the step's CHECK (F12 shows errors).
5. Start a new chat every three or four steps: attach this file and the current `v3.html`, and type **"Continue with STEP NN."**
6. If a reply is cut off, type: "Continue exactly where you stopped, inside the same code block."

| Step | What it does | Also attach |
|---|---|---|
| 01 | Design system and skeleton | nothing else |
| 02A | Question bank, part 1 | json/questionnaire/lists.json, common-sections.json, closing-sections.json, report-checks-common.json, and v3.html |
| 02B | Question bank, part 2 (incident types) | json/incident-types/*.json in batches of 4 or 5, and v3.html (repeat until every type is in) |
| 03 | Utilities, database, state, autosave, home screen | v3.html |
| 04 | Question logic | v3.html |
| 05 | Case shell, questionnaire wizard, summary | v3.html |
| 06 | Incident timezone and UTC | v3.html |
| 07 | Register engine, case timeline, chart and PNG | v3.html |
| 08 | Incident timeline (MITRE ATT&CK) | v3.html |
| 09 | IOC register and CSV export | v3.html |
| 10 | Affected assets register | v3.html |
| 11 | Time log (hours) | v3.html |
| 12 | JSON export / import and Markdown report | v3.html |
| 13 | Case phases, full search, backup reminder | v3.html |
| 14 | Print-ready report | v3.html |
| 15 | Analytics screen | v3.html |
| 16 | Incident types screen | v3.html |
| 17 | Report checklist | v3.html |
| 18 | Final review against acceptance tests | v3.html |
| UPDATE | Update the question bank after editing JSON (use any time) | the edited JSON file(s) and v3.html |

VS Code: attach with `#file:` (for example `#file:copilot-v3/IR-Scoping-v3-Copilot-Prompt.md #file:v3.html`); in Agent mode Copilot can also read the `json/` files itself. Microsoft 365 Copilot: upload the files with the attach button.

***

## For Copilot: how to work with this file

1. This file is the whole specification. When I say "Do STEP NN" (or "Do UPDATE"), carry out ONLY that section, then stop and wait. Never start the next step on your own.
2. The CONTRACT below applies to every step.
3. If a step needs JSON files or v3.html and they are not attached, ask me for them by name (in VS Code Agent mode you may read them from the json/ folder next to this file). Never invent or retype question data.
4. Return only what the step asks for: code blocks labelled with their marker, or the complete file for STEP 01.

## CONTRACT

We are building a single-file web app called "IR Scoping v3". The contract below applies to every step.

WHAT IT IS
An offline case manager for an incident response (DFIR) consultant: pick an incident type, walk through a scoping questionnaire, then manage the case (case timeline, incident timeline mapped to MITRE ATT&CK, IOCs, affected hosts and accounts, time log in minutes) and print a report. v3 shares its saved cases with v1 and v2 (same database and record shape), so it must read and write exactly the data model below.

HARD RULES (apply to every phase)
1. One file, v3.html, inline CSS and vanilla JavaScript. No frameworks, libraries, CDNs, web fonts or network calls.
2. Must run by double-clicking the file (file:// URL) in current Chrome and Edge.
3. Case data is stored in IndexedDB only. localStorage is used only for the theme preference.
4. Never lose typed data: debounced autosave, and flush saves when the tab is hidden or closed.
5. Data-driven: every question, Ask line, report check and shared answer list comes ONLY from the question bank embedded in the page (step 02), built from the JSON files in json/questionnaire/ and json/incident-types/. Never retype that data in JavaScript. Other settings (statuses, colours, page size) live in config constants, not in logic.
6. 'use strict', const/let, small functions, clear comments, no clutter.
7. Escape all user text before putting it into HTML or SVG, using esc().
8. Never use the em dash character in UI text or generated output.
9. Never use alert(), confirm() or prompt(). Use the custom <dialog> modal.
10. In every step after step 01, return ONLY new or changed code, as separate code blocks. Start each block with a comment naming the marker it goes under, for example "// PASTE BELOW: // @@JS-DB" or "/* PASTE BELOW: @@CSS-HOME */". If an existing function must change, say "REPLACE FUNCTION name" and give the whole new function. Do not repeat unchanged code.

MARKERS (created in step 01, never removed)
HTML: <script type="application/json" id="question-bank"> sits directly before the main <script>; step 02 fills it.
CSS: @@CSS-BASE, @@CSS-HOME, @@CSS-WIZARD, @@CSS-REGISTERS, @@CSS-REPORT, @@CSS-PRINT
JS, in this order: @@JS-CONFIG-CORE, @@JS-CONFIG-QUESTIONS, @@JS-CONFIG-CASE, @@JS-UTILS, @@JS-DB, @@JS-STATE, @@JS-UI, @@JS-QUESTION-LOGIC, @@JS-TIMEZONE, @@JS-METRICS, @@JS-REGISTER-HELPERS, @@JS-REGISTERS (inside the REGISTERS object literal), @@JS-HOME, @@JS-SHELL, @@JS-WIZARD, @@JS-SUMMARY, @@JS-REGISTER-VIEW, @@JS-CHART, @@JS-REPORT, @@JS-EXPORT, @@JS-INIT

DATA MODEL (one IndexedDB record per case; database "ir-scoping", version 1, store "incidents", keyPath "id", index "updatedAt")
{
  id (UUID), title, clientName, incidentType (the primary type), extraTypes (array of additional type ids, may be empty),
  phase: 'scoping' | 'collection' | 'analysis' | 'reporting' | 'completed' | 'closed',
  status: 'draft' | 'complete'   (kept in sync: completed and closed mean complete),
  createdAt, updatedAt (ISO strings), currentStep (wizard section index),
  answers: { questionId: string | number | string[] },
  budget: { hoursCap: number or '', warnPct: number (default 80) },
  lastExportedAt: ISO string or null (set only by JSON export),
  checks: { reportCheckId: 'Yes' | 'No' | 'N/A' } (Report checklist answers; step 17),
  timeline: [], attack: [], iocs: [], assets: [], hours: []
}
Register items always have id and createdAt, plus updatedAt after an edit. Datetimes are "YYYY-MM-DDTHH:MM" strings in the incident timezone; dates are "YYYY-MM-DD".

SHARED NAMES (use exactly these so steps fit together)
Bank: BANK, LISTS, OPTION_SOURCES, bankSections, INCIDENT_TYPES, PHASES, SEVERITIES, COUNTRIES, DATA_TYPES, TIMELINE_GROUPS, TIMELINE_EVENT_TYPES, IOC_TYPES, IOC_CONFIDENCE, ASSET_STATUSES, ATTACK_TACTICS, ATTACK_TECHNIQUES, QUESTIONNAIRE, REPORT_CHECKS_COMMON, REPORT_CHECKS
Utilities: $, $$, esc, uuid, nowISO, clone, errMsg, fmtDateTime, fileSlug, dateStamp, download(filename, content, mime), isEmpty, normOptions
DB: DB.open, DB.getAll, DB.get, DB.put, DB.putMany, DB.delete, DB.mode ('idb' or 'memory')
State: state, markDirty(touch = true), commit(), flushSave(), setSaveStatus, normalizeRecord, newRecord, upsertLocal
UI: applyTheme, showBanner, toast(msg, kind, ms), openModal({title, body, buttons, onOpen}), confirmModal(title, message, label, danger)
Questions: QINDEX, getSections(type), getVal, setVal, isVisible, sectionStats, overallStats, formatAnswer(q, v, rec), typeLabel
Timezone: incidentTz, isValidTz, zonedToUtc, utcHint, fmtUtc, fmtLocal, fmtDate, nowLocalString, todayLocal, utcOf
Views: renderHome, renderList, openIncident, renderShell(tab, html), refreshTabs, openTab, updateHeader, renderWizard, renderSummary, renderRegister(key), renderReport
Registers: REGISTERS (object keyed by register key), REGISTER_ORDER
Chart/export: buildTimelineSVG, exportChartPNG, exportIncidentsJSON, exportAllJSON, toMarkdown, exportMarkdown

***

## STEP 01: Design system and skeleton

STEP 01: Design system and skeleton. Return the COMPLETE v3.html for this step only.

Create the full page structure with all markers from the contract, the complete design system CSS, and a working top bar with a theme toggle. JS sections that later phases fill should contain just their marker comment (plus anything listed below).

PAGE STRUCTURE
<head>: charset, viewport, <title>IR Scoping v3</title>, a tiny inline script that reads localStorage key "ir-scoping-theme" (in try/catch) and sets data-theme on <html> before first paint, then <style>.
<body>:
- header.topbar: brand button #brandHome (26px rounded square mark with "IR", gradient 135deg from accent to #8a5cf6, white bold text; then "IR Scoping" and a small accent "v3"), spacer, span#saveStatus (aria-live polite), ghost button #themeToggle.
- div#dbBanner.banner (role alert, hidden)
- main#app (tabindex -1)
- footer#appFoot.app-foot
- dialog#modal.modal
- div#toasts.toasts (aria-live polite)
- input#importFile type file, accept ".json,application/json", hidden
- <script type="application/json" id="question-bank">{}</script> (empty for now; step 02 fills it)
- <script> with 'use strict' and the JS markers in contract order. In the @@JS-REGISTERS area write: const REGISTERS = { // @@JS-REGISTERS  }; and below it: const REGISTER_ORDER = ['timeline','attack','iocs','assets','hours'].filter(k => REGISTERS[k]);

THEME TOKENS
Define each token as a CSS custom property on :root and [data-theme="dark"] (default), overridden on [data-theme="light"].
Dark: bg #0e1319, surface #151c25, surface-2 #1c2531, surface-3 #243041, border #2b3747, text #e4ebf2, muted #8f9db0, accent #4f9cf9, accent-strong #7ab4ff, accent-contrast #06121f, danger #f0616d, success #3fb97a, warn #e3b341, focus #7ab4ff, shadow "0 8px 30px rgba(0,0,0,.45)", color-scheme dark.
Light: bg #f3f5f8, surface #ffffff, surface-2 #f6f8fb, surface-3 #e9eef5, border #d3dbe6, text #17202b, muted #5b6878, accent #1d64d8, accent-strong #134ea9, accent-contrast #ffffff, danger #c7323f, success #1e8a55, warn #a5710a, focus #1d64d8, shadow "0 8px 30px rgba(20,30,50,.15)", color-scheme light.

BASE CSS (under @@CSS-BASE)
- box-sizing border-box; [hidden] { display:none !important }.
- Body: bg token, text token, font 15px/1.5 "Segoe UI", system-ui, -apple-system, Roboto, "Helvetica Neue", Arial, sans-serif.
- h1 1.45rem, h2 1.2rem, line-height 1.25, margin 0. Classes .muted, .small (0.85rem), .sr-only.
- :focus-visible outline 2px focus token, offset 2px, radius 4px. kbd: monospace 12px, 1px border, 2px bottom border, radius 4px, surface-2.
- Top bar: sticky top 0, z-index 20, flex, gap 12px, padding 10px 20px, surface bg, bottom border.
- Save status 0.85rem muted; data-state "saved" shows an 8px green dot before the text, "pending"/"saving" an amber dot, "error" danger bold, "memory" warn.
- Banner: padding 12px 20px, background danger mixed 18% into surface, danger bottom border.
- main: max-width 1240px, centred, padding 24px 20px 64px. Footer: same width, 0.8rem muted.
- Buttons .btn: inline-flex centred, min-height 38px, padding 7px 14px, surface-2 bg, border, radius 8px, weight 550, hover surface-3. Variants: .primary (accent bg/border, accent-contrast text, hover accent-strong), .danger (danger text, border mixed 50% danger), .danger.solid (danger bg, white text), .success (success text), .small (min-height 32px, padding 4px 10px, 0.85rem), .ghost (transparent). Disabled opacity .45. .link-btn: unstyled text button, weight 600, hover accent-strong underline.
- Inputs (text, search, number, date, time, datetime-local, email), select, textarea: width 100%, min-height 40px, padding 8px 11px, surface-2 bg, border, radius 8px, inherit font. Textarea min-height 96px, vertical resize. Focus: outline 2px focus at offset 0 and focus border.
- .card: surface bg, 1px border, radius 12px.
- .badge: pill, padding 2px 9px, 0.78rem, weight 650, uppercase. .badge.type: surface-3 bg, normal case. .badge.tint: background = color-mix(in srgb, var(PC) 22%, transparent), text = color-mix(in srgb, var(PC) 70%, var(text)), where PC is a custom property set inline per badge.
- .flag (tiny pill 0.72rem weight 650) with .warn and .danger tints (20% mix). .chip (0.8rem pill with border, muted) and .chip.warn.
- .notice (flex row, padding 10px 14px, radius 8px, border) and .notice.warn (warn 50% border, warn 10% into surface bg).
- .stat-grid: grid repeat(auto-fill, minmax(150px, 1fr)) gap 10px. .stat: padding 12px 14px, border, radius 10px, surface-2. .stat .num 1.55rem bold tabular-nums; .lbl 0.82rem muted 600; .sub 0.78rem muted. .stat.warn/.danger colour the number.
- .empty-state: centred muted, padding 48px 20px.
- Toasts: fixed bottom-right 18px, grid gap 8px, max-width min(420px, 100vw minus 36px). .toast: padding 11px 14px, radius 10px, surface-3, border, 4px left border (accent; .success, .warn, .error variants), shadow, 0.18s slide-up animation.
- Modal: dialog width min(560px, 100vw minus 32px), padding 0, surface, border, radius 14px, shadow; backdrop rgba(5,10,18,.6) with 2px blur. Inner form padding 20px 22px; .modal-body grid gap 14px; label.f grid gap 5px bold; .modal-actions flex, gap 8px, margin-top 20px; ul.msgs max-height 220px scroll; .opt radio cards (border, radius 8px, checked = accent border and 10% tint).
- Table list (table.list): full width, collapsed; cells padding 11px 14px, bottom border; th 0.78rem uppercase muted 650; row hover surface-2; .row-actions flex wrap gap 6px right-aligned. At max-width 820px: hide thead, rows and cells become blocks, each cell shows its data-label as a muted prefix (except .title-cell).
Leave the other CSS markers empty.

JS FOR THIS PHASE
- Under @@JS-UTILS: $ and $$ (querySelector helpers), esc (escape & < > " ').
- Under @@JS-UI: applyTheme(theme) sets data-theme, sets the toggle text to "Light mode" in dark theme and "Dark mode" in light theme, saves to localStorage in try/catch. toast(msg, kind = 'info', ms = 3500).
- Under @@JS-INIT: an init function that applies the current theme, wires #themeToggle, and puts a placeholder in #app: a card saying "Skeleton ready. Next phases add features." plus three sample buttons (primary, default, danger) and three badges, so the styling can be checked. Footer text: "IR Scoping v3.0.0".

CHECK
Opening the file shows the dark top bar and sample card; the theme toggle switches all colours and is remembered after reload; no console errors.

## STEP 02A: Question bank, part 1

STEP 02A: Question bank, part 1 (lists, common sections, closing sections, common report checks). Return code blocks only.

The attached JSON files are the ONLY source of questions, Ask lines, report checks and answer lists. Copy them exactly; do not reword, reorder, add or drop anything, and do not convert them to JavaScript.

1. Replace the empty placeholder <script type="application/json" id="question-bank">{}</script> with a JSON object of this exact shape (every value is the content of the named file with its "_notes" key removed):
{
  "lists": <json/questionnaire/lists.json>,
  "common": <json/questionnaire/common-sections.json>,
  "closing": <json/questionnaire/closing-sections.json>,
  "reportChecksCommon": <json/questionnaire/report-checks-common.json>,
  "types": {}
}
Write each value on one line (compact JSON) to keep the file small. If any text contains "</", write it as "<\/".

2. Under @@JS-CONFIG-QUESTIONS paste this loader exactly as written:
/* ---------------- Question bank (embedded JSON) ---------------- */
const BANK = JSON.parse(document.getElementById('question-bank').textContent);
const LISTS = BANK.lists;

const INCIDENT_TYPES = LISTS.incidentTypeOrder.map(id => ({ id, label: BANK.types[id].incidentType.label }));
const PHASES = LISTS.phases;
const SEVERITIES = LISTS.severities;
const COUNTRIES = LISTS.countries;
const DATA_TYPES = LISTS.dataTypes;
const TIMELINE_GROUPS = LISTS.timelineGroups;
const TIMELINE_EVENT_TYPES = LISTS.timelineEventTypes;
const IOC_TYPES = LISTS.iocTypes;
const IOC_CONFIDENCE = LISTS.iocConfidence;
const ASSET_STATUSES = LISTS.assetStatuses;
const ATTACK_TACTICS = LISTS.attackTactics;
const ATTACK_TECHNIQUES = LISTS.attackTechniques;

/* Shared lists a question can use with "optionsFrom". */
const OPTION_SOURCES = {
  PHASES: () => PHASES.map(p => ({ value: p.id, label: p.label })),
  INCIDENT_TYPES: () => INCIDENT_TYPES.map(t => ({ value: t.id, label: t.label })),
  SEVERITIES: () => SEVERITIES,
  COUNTRIES: () => COUNTRIES,
  DATA_TYPES: () => DATA_TYPES,
};

function bankSections(sections) {
  return sections.map(s => ({ ...s, questions: s.questions.map(q => {
    if (!q.optionsFrom) return q;
    const { optionsFrom, ...rest } = q;
    if (!OPTION_SOURCES[optionsFrom]) console.warn(`[config] "${q.id}" uses unknown optionsFrom "${optionsFrom}"`);
    return { ...rest, options: OPTION_SOURCES[optionsFrom] ? OPTION_SOURCES[optionsFrom]() : [] };
  }) }));
}

const QUESTIONNAIRE = {
  commonSections: bankSections(BANK.common.sections),
  typeSections: Object.fromEntries(LISTS.incidentTypeOrder.map(id => [id, bankSections(BANK.types[id].sections)])),
  closingSections: bankSections(BANK.closing.sections),
};

const REPORT_CHECKS_COMMON = BANK.reportChecksCommon.reportChecks;
const REPORT_CHECKS = Object.fromEntries(LISTS.incidentTypeOrder.map(id => [id, BANK.types[id].reportChecks || []]));

3. The page will log errors until step 02B adds the incident types (BANK.types is empty); that is expected.

CHECK
The question-bank block is valid JSON (paste it into any JSON validator if unsure) and contains the four keys plus an empty "types".

## STEP 02B: Question bank, part 2 (incident types)

STEP 02B: Question bank, part 2 (incident types). Return only the changed "types" part of the question bank.

Add every attached json/incident-types/<id>.json file to the question bank in v3.html, inside "types", keyed by the file's incidentType.id, with its "_notes" key removed:
"types": {
  "<id>": { "incidentType": {...}, "sections": [...], "reportChecks": [...] },
  ...
}
Copy each file exactly (compact JSON, one type per line). Do not reword, reorder, add or drop anything. Keep any types already in the bank.
Put the types in the order of lists.incidentTypeOrder in the bank.

CHECK (after the last batch)
Every id in lists.incidentTypeOrder has an entry in "types". Open v3.html: no console errors about BANK.types. In the console, QUESTIONNAIRE.typeSections has one key per incident type.

## STEP 03: Utilities, database, state, autosave, home screen

STEP 03: Utilities, database, state, autosave and the home screen. Return only code blocks per marker (contract rule 10).

@@JS-CONFIG-CORE
APP_VERSION '3.0.0', SCHEMA_VERSION 3, DB_NAME 'ir-scoping', DB_VERSION 1, STORE 'incidents', THEME_KEY 'ir-scoping-theme', AUTOSAVE_DELAY 400.
INCIDENT_TYPES, PHASES, SEVERITIES and COUNTRIES already exist (step 02 builds them from the question bank). Add TYPE_IDS = INCIDENT_TYPES.map(t => t.id) and typeLabel(id) returning the label, "Unknown (id)" or "Not set".
ALL_REGISTER_KEYS = ['timeline','attack','iocs','assets','hours'] (used by normalizeRecord even before registers exist).

@@JS-UTILS (add)
uuid (crypto.randomUUID with a getRandomValues v4 fallback), nowISO, clone (structuredClone with JSON fallback), errMsg, fmtDateTime(iso) en-GB "07 Oct 2026, 09:15", fileSlug (lowercase, non-alphanumerics to single hyphens, max 60, default "incident"), dateStamp (YYYY-MM-DD), isEmpty (undefined, null, '' or empty array), normOptions (strings become {value, label}), download(filename, content, mime): Blob, object URL, hidden <a download>, click, revoke after 1.5s.

@@JS-DB
Promise-based DB object: open() resolves true or false. On missing IndexedDB or open error, switch to an in-memory Map (mode 'memory'), keep the error in DB.error. onupgradeneeded creates the store and the updatedAt index. onversionchange closes the DB and calls showBanner("Database was upgraded in another tab. Reload this page to continue saving."). A private _tx(mode, fn) runs fn(store) and resolves with the request result on transaction complete, rejecting on error or abort. Methods getAll, get, put, putMany (single transaction), delete, each with the memory fallback (store clones).

@@JS-STATE
state = { view: 'home', activeTab: null, incidents: [], current: null, search: '', phaseFilter: 'all', dirty: false, touched: false, saveTimer: null, saveChain: Promise.resolve(), saveErrorShown: false, regEditId: null }.
newRecord({title, clientName, incidentType}) following the data model (phase 'scoping', status 'draft', empty registers, budget {hoursCap: '', warnPct: 80}, lastExportedAt null).
normalizeRecord(rec): ensure answers object and every ALL_REGISTER_KEYS array; derive phase from status if missing ('complete' becomes 'closed', else 'scoping'); sync status from phase; default budget; invalid lastExportedAt becomes null. Returns rec.
upsertLocal(rec): put a normalised clone into state.incidents.
markDirty(touch = true): set dirty (and touched if touch), status "pending", debounce flushSave by AUTOSAVE_DELAY.
commit(): set dirty and touched, return flushSave().
flushSave(): if nothing dirty return state.saveChain. Otherwise clear dirty; if touched, set updatedAt = now and clear touched; snapshot with clone; chain DB.put onto state.saveChain; on success upsertLocal and status "saved"; on failure set dirty again, status "error", toast once "Could not save: <error>. Retrying. Export to JSON if this persists.", retry after 5 seconds.
setSaveStatus(s): blank when no case is open; states pending "Unsaved changes", saving "Saving...", saved "Saved HH:MM:SS", error "Save failed", memory "Held in memory only" (used instead of saved in memory mode).
Listeners: visibilitychange (hidden) and pagehide call flushSave; beforeunload calls flushSave and, in memory mode with cases present, asks to confirm leaving.

@@JS-UI (add)
showBanner(html). openModal({title, body, buttons, onOpen}) returning Promise<{value, form}>: renders a <form method="dialog"> with h2, .modal-body and .modal-actions. Buttons: {label, value, kind, cancel, autofocus}. Submit buttons come first in the DOM and the actions row uses flex-direction row-reverse with justify-content flex-start (so Enter triggers the primary button and it still appears on the right). Cancel buttons are type="button" and close with ''. Escape cancels. confirmModal(title, message, confirmLabel = 'Confirm', danger = false) resolves true/false; when danger, autofocus Cancel and use 'danger solid' for the confirm button.

@@CSS-HOME
.home-head (flex wrap, space-between, align end, gap 16px, margin-bottom 18px), .actions (flex wrap gap 8px), .search-row (flex gap 12px, input max-width 460px), .phase-filter, .pf chips (pill buttons min-height 34px, border, surface bg, 0.88rem 600; .active = accent bg and accent-contrast text; .pf-n count 0.75rem at 75% opacity), .flags (flex wrap gap 4px, margin-top 4px), .match (small, margin-top 3px; mark = warn 40% tint).

@@JS-HOME
renderHome(): flush saves, set view 'home', clear current, load state.incidents = (await DB.getAll()).map(normalizeRecord) (toast on error). Render: h1 "Incidents", subtitle "Cases saved in this browser.", buttons "Import JSON" (#btnImport clicks #importFile), "Export all" (#btnExportAll, for now a toast "Arrives in step 12"), "New incident" (primary). Then div#backupBanner (empty for now), div#phaseFilter (empty for now), search input #search (placeholder "Search everything: case IDs, answers, events, IOCs, hosts...") with span#listCount "N of M" (typing re-renders the list after a 150 ms pause, debounced with state.searchTimer), and div#list.card. Document title "IR Scoping v3".
renderList(): filter by search (case-insensitive over title, client, type label for now), sort by updatedAt newest first. Empty states: "No incidents yet" / "Start a new case, or import a JSON export." and "No incidents match ...". Table columns (only these): Case ID (link-btn data-act open showing answers.engagement_ref, falling back to the title for older cases), Incident type, Customer, Severity, Case logged ("07 Oct 2026" style, followed by an age tag: ageDays(date) = whole calendar days from the logged date to today, shown by ageTagHTML as a small grey pill "0 days" / "1 day" / "12 days", "Future date" if the date is after today, nothing if there is no date; title "12 days since the case was logged"; CSS .age-tag: inline-block, margin-left 6px, padding 1px 8px, radius 999px, surface-3 background, text colour, 0.75rem, 650, tabular-nums), actions (kept on one line on screens wider than 820px) as 34px square icon buttons with inline SVG icons, title and aria-label: arrow "Open case", braces "Export JSON", document "Export Markdown report", bin "Delete case" (danger). Show HOME_PAGE_SIZE = 10 rows per page with a pager under the table ("Showing 11 to 20 of 34", Previous, page numbers with "…" gaps, Next; hidden when there is only one page); searching or changing the phase filter returns to page 1. Cells carry data-label. Use event delegation on #list.
New incident modal fields: Incident types (fieldset "Incident types (tick all that apply)" with one checkbox per INCIDENT_TYPES entry, name "types", one per row in a bordered scrolling list, max-height 300px; at least one required, enforced with setCustomValidity "Tick at least one incident type." on the first checkbox; the first ticked type in list order is saved as rec.incidentType, the rest as rec.extraTypes), Case ID (placeholder "Internal case / matter reference"), Case logged date (date picker, defaults to today), Customer, Geolocation (select, "Select country..." then COUNTRIES), Severity (select, "Select severity..." then SEVERITIES). The title is the Case ID on its own (never combined with other values), or "Untitled incident" when there is no Case ID. Customer is saved as clientName; Case ID, Case logged date, Geolocation and Severity are saved as answers engagement_ref, case_logged, geolocation and severity (only when filled in). Save with DB.put, upsertLocal, then openIncident(id) (for now openIncident just toasts "Opened <title>"; step 05 replaces it).
Delete: confirmModal("Delete incident?", "This permanently deletes <b>title</b> (client) from this browser. Export it first if you may need it.", "Delete", true).
JSON and Markdown buttons: toast "Arrives in step 12" for now.

@@JS-INIT (replace the step 01 placeholder)
init: apply theme, wire theme toggle and #brandHome (renderHome), await DB.open(); if false, showBanner("<strong>Warning: IndexedDB is unavailable.</strong> <error> Data is held in memory only and will be lost when this tab closes. Export to JSON before closing. Common causes: private / InPrivate window, browser storage disabled, or strict site-data settings."); else call navigator.storage.persist() ignoring errors. Footer: "IR Scoping v3.0.0 · schema 3 · storage: IndexedDB (this browser profile)" or "memory only". Then renderHome().

CHECK
Create and delete cases; they survive a browser restart; search filters the list; at 400px width the table becomes cards.

## STEP 04: Question logic

STEP 04: Question logic. Return code blocks per marker.

The questions themselves already come from the question bank (step 02): QUESTIONNAIRE.commonSections, .typeSections and .closingSections. Each question may carry ask (spoken prompt), optionsFrom (already resolved to options by bankSections), help, placeholder, suggestions, showIf, bind, row and required. Do not add question data in JavaScript.

Question schema reminder:
Question schema: { id (unique across ALL sections), label, type, options?, help?, placeholder?, suggestions?, bind?, showIf?, required?, row? }
row: consecutive questions with the same row key render side by side in one row (one equal column each).
Types: text, textarea, number, date, time, datetime, select, multiselect, yesno (Yes/No/Unknown, or the question's own options list such as ['Yes', 'No']), timezone.
bind: store on the record instead of answers ('title', 'clientName', 'phase', 'types').
showIf: { q, equals } | { q, in: [...] } | { q, notEquals } | { q, notEmpty: true }.
Section: { id, title, description, questions, group?, short? }. group overrides the default heading (e.g. 'Containment'); short is the name used in the sidebar, jump list, section heading and Summary (title is still used in the report, Markdown and progress line).

@@JS-QUESTION-LOGIC
- QINDEX: Map of every question across common, all type sections and closing sections; console.warn on duplicate ids and on showIf pointing to unknown ids.
- caseTypes(rec): [primary, ...extraTypes] without repeats or blanks; caseTypesLabel(rec): their labels joined with " + ".
- getSections(arg): arg is a case (use caseTypes) or a single type id. Returns common (group "Common") + each type's typeSections in that order (group = that type's label; a section's own group, e.g. Containment, wins) + closing (group "Scope"), each section copied with a group property. Pass the case everywhere (getSections(rec)).
- getVal(rec, q) / setVal(rec, q, v): use rec[q.bind] when bound; empty answers are deleted from answers (bound fields become ''). bind 'types' is special: getVal returns caseTypes(rec); setVal keeps rec.incidentType if it is still ticked (otherwise the first ticked type, or '') and stores the other ticked types in rec.extraTypes.
- conditionMatches(value, cond): arrays match if any element matches.
- isVisible(rec, q): true without showIf; false if the controller is hidden; otherwise conditionMatches.
- sectionStats(rec, s) => {total, answered} over visible questions; overallStats(rec) sums all sections.
- formatAnswer(q, v, rec): null when empty; selects and multiselects show option labels (multiselect joined with ", "); datetime shows "YYYY-MM-DD HH:MM" for now (step 06 adds the timezone).

CHECK
In the console: getSections('ransomware').length is 17, there are no duplicate-id warnings, and isVisible works for prior_incidents_details after setting answers.prior_incidents = 'Yes'.

## STEP 05: Case shell, questionnaire wizard, summary

STEP 05: Case shell, questionnaire wizard and summary. Return code blocks per marker.

@@JS-CONFIG-CASE (add)
PHASES ({id, label, color}; ids are stored on cases) comes from the question bank (step 02); do not redefine it. DONE_PHASES = [completed, closed] (finished: status complete, excluded from Open cases). phaseOf(id).

@@CSS-WIZARD
- .inc-head: flex wrap, space-between, gap 12px 20px, margin-bottom 16px; .meta row (flex wrap gap 8px, muted); .actions buttons.
- .phase-pick: inline-flex label "Phase" + small select (auto width, min-height 30px, padding 3px 8px, left border 4px coloured by the phase).
- .tabs: flex wrap, gap 2px, bottom border, margin-bottom 18px. .tab: borderless button, 2px transparent bottom border, muted 600, padding 10px 12px; hover text colour; .active = accent-strong text, accent bottom border. .tab-badge: pill min-width 20px, padding 0 7px, surface-3, 0.74rem 650; .warn and .danger variants with 25% tints.
- .progress-meta (flex space-between, 0.88rem muted), .progress-bar (8px pill, surface-3) with inner span gradient accent to #8a5cf6, width transition.
- .wiz-body: grid 280px 1fr, gap 20px. .sec-nav: sticky top 72px, max-height viewport minus 92px, scroll, padding 10px. .nav-group: 0.74rem uppercase muted 700. .nav-item: full-width row, label left, count right (0.76rem muted); hover surface-2; .active = accent 18% tint, accent-strong text; .done count green with a check mark prefix.
- .jump-wrap (hidden on wide screens). .sec-form padding 22px 24px; header with group label (0.78rem uppercase accent 700), h2, description muted, bottom border.
- .q-row: grid, grid-template-columns repeat(var(--cols), minmax(0, 1fr)), gap 0 16px; date inputs inside have no max-width; 1 column below 700px.
- .q (margin-bottom 20px), labels and legends 600, .help 0.85rem muted, .q.conditional (padding-left 14px, 2px left border accent 45%).
- .q .ask: flex row, gap 8px, baseline aligned, margin -1px 0 8px, 0.95rem, italic, accent-strong colour. .ask-tag: not italic, 0.68rem bold uppercase, letter-spacing 0.5px, padding 1px 6px, radius 4px, background accent mixed 16% with transparent, accent-strong text.
- Choice cards .choice-grid repeat(auto-fill, minmax(230px, 1fr)); .choice with checkbox; checked = accent border + 12% tint.
- Segmented yes/no .seg (three radio labels, min-height 38px, padding 6px 18px, checked = accent bg, accent-contrast text) and .clear-btn (underlined muted link).
- .wiz-foot (flex space-between, top border, padding-top 16px), .kbd-hint 0.8rem muted.
- Summary: .sum-sec cards (padding 16px 20px), header row (h2 1.05rem, count, Edit button), dl grid minmax(200px, 38%) 1fr with dashed row separators, dd pre-wrap, .empty italic.
- At 900px and below: single column, hide .sec-nav, show .jump-wrap. At 700px summary dl stacks.

@@JS-SHELL
- incidentHeaderHTML(): h1#incTitle; meta: badge#incType (caseTypesLabel, all of the case's types), span#incClient, badge#incTz, label.phase-pick with select#phaseSelect (options from PHASES), span#backupChip.chip; actions: "All incidents" #btnHome, "Export JSON" #btnJson, "Export Markdown" #btnMd (toast "Arrives in step 12" until then).
- updateHeader(): fills title (or "Untitled incident"), type label, client (or "No client set"), timezone badge "Timezone not set" (step 06 completes it), phase select value and its border colour, document title "<title> - IR Scoping v3". Leave the backup chip empty until step 13.
- renderShell(tab, innerHtml): sets state.activeTab, clears app.onclick, renders header + nav#tabs + div#view, wires header buttons, phase select (setPhase), tab clicks (openTab), scrolls to top.
- refreshTabs(): tabs Questionnaire (badge answered/total), Summary, then one tab per REGISTER_ORDER key (label REGISTERS[k].tab, badge from REGISTERS[k].tabBadge(rec) if defined, else the item count, hidden when 0), then Report (only if renderReport exists). Active tab gets aria-current="page".
- openTab(tab): flushSave then route to renderWizard(true), renderSummary(), renderReport() or renderRegister(tab).
- setPhase(id): set phase and status, commit(), updateHeader(), toast "Phase set to X."
- REPLACE FUNCTION openIncident(id): load, normalizeRecord, clamp currentStep, set state.current, status saved, renderWizard(true).

@@JS-WIZARD
- renderWizard(focusFirst): renderShell('wizard', ...) with progress area, left sidebar nav#secNav, jump select (optgroups by group), and form#secForm (novalidate) containing the section header, the questions (via renderQuestions(rec, questions): consecutive questions sharing a row key are wrapped in div.q-row with style --cols set to their count; others render alone) and the footer (Back disabled on the first section; Next, or "Review summary" on the last), and the hint "Enter in a single-line field: next section. Ctrl + Enter: next from anywhere."
- refreshChrome(): rebuild sidebar (group headings, "answered/total" counts, done and active states), jump select, progress text "Section 3 of 10: <title>" and "X of Y questions answered (Z%)", progress bar width, and refreshTabs().
- renderField(rec, q): wrapper div.q[data-qid] (hidden when not visible, .conditional when it has showIf). Label for single inputs; fieldset + legend for multiselect and yesno. Directly under the label, when q.ask exists, show p.ask: a small tag span.ask-tag "ASK" followed by the spoken prompt. Then the optional help paragraph linked with aria-describedby. Controls: textarea rows 4; number (min 0, step any); date; time; datetime (datetime-local); select with "Select..." first, plus a "(not in current list)" option for unknown stored values; multiselect checkbox cards; yesno segmented radios with a Clear button shown when answered; text with optional datalist from q.suggestions; timezone renders a plain select for now (step 06 completes it).
- readField(wrap, q) for each type (multiselect returns array, number returns Number or '').
- Input and change events on the form: setVal, markDirty(), updateHeader when the question is bound, toggle conditional visibility in place (do not re-render; focus must stay), refreshChrome. Clear button resets the radios.
- Keyboard: Enter in single-line inputs (text, number, date, time, datetime-local) without a datalist goes Next; Ctrl or Cmd + Enter anywhere in the wizard goes Next (global keydown, ignored when the modal is open).
- goToStep(i): set currentStep, markDirty(false) (navigation does not change updatedAt), flushSave, renderWizard(true). goNext(): last section goes to renderSummary().
- Focus the first visible field only when matchMedia('(pointer: fine)') matches.

@@JS-SUMMARY
renderSummary(): renderShell('summary', ...): a muted line "X of Y questions answered. Created <date>, last updated <date>." then one .sum-sec card per section: "<title> (<group>)", "answered/total", Edit button (data-step) that calls goToStep; definition list of visible questions with formatAnswer or "Not answered". Set app.onclick after renderShell to handle the Edit buttons.

CHECK
New incident opens the questionnaire; conditional questions appear without losing focus; Enter moves on; refresh keeps the answers and section; sidebar counts and tab badge update live; Summary Edit jumps to the right section; the phase select persists.

## STEP 06: Incident timezone and UTC

STEP 06: Incident timezone and UTC conversion. Return code blocks per marker and any replaced functions.

@@JS-CONFIG-CORE (add) TZ_QUESTION_ID = 'discovery_tz'.
@@JS-TIMEZONE
- TIMEZONES: ['UTC', ...Intl.supportedValuesOf('timeZone')] de-duplicated, with a short fallback list (UTC, Europe/London, Europe/Dublin, Europe/Paris, Europe/Berlin, Europe/Helsinki, America/New_York, America/Chicago, America/Denver, America/Los_Angeles, Asia/Dubai, Asia/Kolkata, Asia/Singapore, Asia/Tokyo, Australia/Sydney).
- BROWSER_TZ from Intl.DateTimeFormat().resolvedOptions().timeZone.
- incidentTz(rec), isValidTz(tz) (try new Intl.DateTimeFormat with timeZone).
- tzOffsetMs(ms, tz) via formatToParts (hourCycle h23); zonedToUtc(local, tz): parse "YYYY-MM-DDTHH:MM", guess UTC, subtract the offset, then re-check the offset at the result and correct (two passes, correct across DST). Return null when invalid.
- fmtUtc(date) "YYYY-MM-DD HH:MM UTC"; fmtOffset(ms) "UTC+01:00".
- utcHint(rec, value): no timezone: "Set the incident timezone (Case summary) to see UTC."; invalid: "Unrecognised timezone "X". Pick one from the list to see UTC."; empty value: "Enter in Europe/London."; else "Europe/London (UTC+01:00) = 2026-10-07 08:30 UTC".
- fmtLocal("2026-10-07T09:30") => "07 Oct 2026 09:30" and fmtDate("2026-10-07") => "07 Oct 2026" using string parsing only (never a Date object, to avoid shifting).
- nowLocalString(tz) "YYYY-MM-DDTHH:MM" for now in that zone (browser zone if unset or invalid); todayLocal(tz); utcOf(rec, local) returns a Date or null.

REPLACE FUNCTION renderField: datetime renders a .dt-row with the input and span.utc-hint[data-utc-for] showing utcHint. timezone renders a select ("Select timezone..." then all TIMEZONES, plus "X (not a recognised timezone)" for unknown stored values) and a small button "Use browser timezone (<zone>)" that sets the select and fires change.
REPLACE the form input handler so that changing the timezone question or any datetime refreshes every UTC hint in the section and updates the header timezone badge.
REPLACE FUNCTION formatAnswer: timezone shows "Europe/London (currently UTC+01:00)"; datetime shows "2026-10-07 09:30 Europe/London (2026-10-07 08:30 UTC)" or "2026-10-07 09:30 (timezone not set)".
REPLACE FUNCTION updateHeader so #incTz shows incidentTz(rec) or "Timezone not set".
CSS (under @@CSS-WIZARD): .dt-row flex wrap gap 8px 14px align centre; .dt-row select max-width 340px; .utc-hint 0.88rem muted tabular-nums; date/time inputs max-width 280px.

CHECK
Europe/London: 2026-07-01 09:30 => 08:30 UTC; 2026-12-01 09:30 => 09:30 UTC. America/New_York 2026-10-07 09:30 => 13:30 UTC. Asia/Kolkata 09:30 => 04:00 UTC.

## STEP 07: Register engine, case timeline, chart and PNG

STEP 07: Generic register engine, the case timeline register, the SVG timeline chart and PNG export. Return code blocks per marker.

REGISTER DEFINITION SHAPE
{ tab, title, singular, intro, fields: [...], sort(a, b), columns: [...], chart?, panel?(rec), wirePanel?(el), normalize?(item, rec) => {item} or {error}, dedupeKey?(item), merge?(a, b), rowActions?: [{id, label, show(item), apply(item)}], rowClass?(item, rec), toolbar?: [{id, label, run(rec)}], tabBadge?(rec) => {text, warn}, afterChange?(rec, before) }
Field: { id, label, type: text|textarea|number|date|datetime|select, required, default: 'now'|'today'|value, options or groups(rec) (optgroups), suggestions(rec) (datalist), placeholder, wide, step, onChange(value, form, rec) }
Column: { label, text(item, rec), html?(item, rec), exportText?(item, rec), cls? }  (text for search and Markdown, html for screen, exportText for sharing such as defanged values)

@@JS-CONFIG-CASE (add)
TIMELINE_GROUPS ({ groupId: {label, color} }) and TIMELINE_EVENT_TYPES ([{id, label, group}]) come from the question bank (step 02); do not redefine them.
TIMELINE_EXPORT_PALETTE: bg #ffffff, surface #f6f8fb, border #d3dbe6, text #17202b, muted #5b6878, line #c3cdd9.

@@JS-REGISTER-HELPERS
whenText(rec, local) "07 Oct 2026 09:30 (2026-10-07 08:30 UTC)"; whenHTML (UTC on a second muted line); dot(color) small coloured circle span; tintBadge(label, color); optOf(options, value); byDatetime sorter; tlType(id); tlGroup(id).

@@JS-REGISTERS: entry timeline
tab "Case timeline", title "Case events", singular "event", intro "Case milestones: access and evidence requested or received, analysis, updates and reports shared."
fields: datetime (label "Date", type date, required, default today; the field id stays "datetime"); type (Event type, required, select with optgroups per TIMELINE_GROUPS); details (Details, textarea, wide, placeholder "e.g. Memory images for DC01 and FS02 requested from client IT").
sort byDatetime. columns: Date ("07 Oct 2026", nowrap), Event (dot + label), Details (pre-wrap). normalizeRecord trims any older "YYYY-MM-DDTHH:MM" timeline values to the date, and import accepts them the same way.
chart: { title "Case timeline", file "case-timeline", build(rec) => { events: [{datetime, title: event label, tag: group label, color: group colour, details}], legend: groups used } }.

@@CSS-REGISTERS
.reg-intro (muted, max-width 900px, margin-bottom 14px); .tl-note (warn notice: padding 10px 14px, radius 8px, warn 50% border, warn 10% background); .tl-layout (grid gap 18px); .tl-form (padding 18px 20px); .tl-fields (grid minmax(280px, auto) and minmax(220px, 1fr), gap 14px 18px; .f grid gap 6px; labels 600; .tl-desc spans both columns; textarea min-height 64px; datetime input max-width 260px); .tl-form-actions (flex gap 8px, margin-top 14px); .form-error (danger 600); .req (danger asterisk); .reg-panel (padding 16px 18px); .reg-toolbar (flex wrap space-between, padding 14px 16px 8px, h2 1.05rem); .tl-chart-card (padding 12px, overflow-x auto); .tl-chart svg (block, width 100%, height auto, max-width 960px, centred); .tl-dot (10px circle, margin-right 8px); .table-scroll (overflow-x auto); td.pre (pre-wrap); td.nowrap; td.mono (monospace 0.86rem, break-all); td.num (right, tabular). At 700px .tl-fields becomes one column.

@@JS-REGISTER-VIEW
renderRegister(key): view 'reg:<key>', renderShell(key, ...) with: intro; timezone notice when the register has datetime fields and no incident timezone ("No incident timezone set, so times are stored as entered and no UTC is shown. Set it in the Questionnaire under Case summary."); panel card #regPanel if panel; form#regForm (novalidate) with heading "Add <singular>", fields grid, p#regError, buttons "Add <singular>" (submit), "Cancel edit" (hidden), hint "Ctrl + Enter to save"; chart card if chart (heading + "Export PNG" #regPng + div#regChart role img); table card with title and count, toolbar buttons, div#regTable.
Field rendering: required asterisk; datetime fields show "(<tz>)" after the label, a "Now" button (data-now) and a live UTC hint (data-utc) under the input; selects start with "Select..."; text fields get a datalist from suggestions(rec).
Behaviour: defaults on reset ('now' and 'today' in the incident timezone); input/change refresh the UTC hint and call field.onChange; Ctrl+Enter submits. Submit: read values (trim, Number for number), check required ("Required: A, B."), normalize, dedupe (merge with toast "Merged with existing <singular>." or error "This <singular> is already in the register. Edit the existing entry instead."), add (id, createdAt) or update (updatedAt), remove empty fields, commit(), afterChange, reset form, refreshRegister(). Edit fills the form and switches labels to "Edit <singular>" / "Update <singular>". Delete asks confirmModal. Row quick actions apply then commit. Table: columns with data-label, rowClass, actions (quick actions, Edit, Delete). Empty state "Nothing recorded yet. Add the first <singular> above."
refreshRegister(): panel, chart, table, refreshTabs(). On-screen chart uses the current theme tokens read with getComputedStyle; REPLACE FUNCTION applyTheme to re-render the chart when a register view is open.

@@JS-CHART
buildTimelineSVG(rec, palette, {events, legend}, heading) returns {svg, width, height}:
- Width 960, padding 32. Title 20px bold wrapped; sub line 13px muted "<heading> · <client> · <type> · Timezone: <tz or not set>"; legend circles r 6 with 12px 600 muted labels, wrapping; 1px separator.
- Each event: local datetime 13px weight 650 right-aligned at x 220, UTC 11.5px muted beneath. Date-only events (case timeline) show "07 Oct 2026" with no UTC line, and a zero gap between them reads "same day". Card from x 280 to the right padding: rect rx 8, surface fill, border stroke; 5px colour bar; title 14px bold wrapped (leave room for the tag); tag uppercase 10.5px bold in the event colour, right-aligned; details 13px wrapped, 18px line height; min height 48; 30px gap.
- Vertical 2px line at x 250 from first to last dot; dots r 8 in the event colour with a 3px stroke in the background colour.
- Gap labels between events ("+1h 30m", "+1d 5h", "+3d", "same time") 11px muted, right-aligned at x 234, centred in the gap. Use real UTC differences when the timezone is valid, else wall-clock.
- Footer 11px muted "5 events · Span 6d 5h · Generated <date>".
- Measure text with a hidden canvas 2D context using the same font stack; wrap by words; split long unbroken strings (hashes, paths) by characters.
exportChartPNG(rec, key): build with TIMELINE_EXPORT_PALETTE, load as data:image/svg+xml image, draw on a canvas at 2x (1x if 2x height exceeds 16000px), toBlob PNG, download "ir-<file>-<title slug>-<date>.png", toast "<title> exported as PNG.".

CHECK
Case timeline tab appears; adding, editing and deleting events works; the chart updates live and follows the theme; Export PNG downloads a clean light image.

## STEP 08: Incident timeline (MITRE ATT&CK)

STEP 08: Incident timeline register. Return code blocks per marker.

@@JS-CONFIG-CASE (add)
ATTACK_TACTICS ([{id, label, color}]) and ATTACK_TECHNIQUES ([[id, name, tactic id]]) come from the question bank (step 02); do not redefine them.

@@JS-REGISTER-HELPERS (add): tactic(id) lookup (fallback grey); autoTactic(value, form): if the value starts with a known technique id and the tactic select is empty, set it; assetNames(kind) returning a suggestions function over rec.assets names.

@@JS-REGISTERS: entry attack
tab "Incident timeline", title "Threat actor activity", singular "activity", intro "Threat actor activity reconstructed from evidence, mapped to MITRE ATT&CK tactics. Host and account suggestions come from the Assets register."
fields: datetime (required, no default); tactic (ATT&CK tactic, required, options "Initial Access (TA0001)" style); technique (text, placeholder "e.g. T1021.001 Remote Desktop Protocol", suggestions "T1566.002 Spearphishing Link" style, onChange autoTactic); host (suggestions assetNames('host')); account (suggestions assetNames('account')); artefact (label "Source artefact", placeholder "e.g. Security.evtx 4624, $MFT, UAL, EDR telemetry"); description (textarea, wide).
sort byDatetime. columns: When, Tactic (dot + label), Technique, Host, Account, Source, Description.
chart: title "Incident timeline", file "incident-timeline"; event title = technique or tactic label, tag = tactic label, colour = tactic colour, details = description plus a line "Host: X  |  Account: Y  |  Source: Z" (only parts that exist); legend = tactics used, in tactic order.

VIEW OPTIONS (chart.views: true on this register only)
Add view buttons (same .pf chip style, group "Timeline view") before Export PNG in the chart card toolbar: Vertical, Alternating, Swimlanes, ATT&CK board. Remember the choice in localStorage key "ir-scoping-tl-view" (default vertical); chartSVG(rec, palette, key) returns the selected view (or buildTimelineSVG for registers without views) and is used both on screen and by Export PNG, whose file name includes the view id. All views: width 960, shared header (case title, "<heading> · client · all incident types · Timezone"), footer "N events · Span X · Generated <date>", tactic colours only on dots, bars and pills (text in text colours), long technique names break after a hyphen.
- Vertical: grouped by day with a date pill on the spine ("Tue 29 Sep 2026") plus "N events · <gap> after the previous event"; local time (14px bold) and UTC (11px muted) right-aligned left of a 2px spine; dot r 7 in the tactic colour with a 3px background ring; card from x 204: surface fill, border, 4px coloured left edge, "#n" top right, technique title 14.5px bold, a row of chips (tactic pill: 18% tint of the tactic colour with a coloured dot and text in the text colour; Host / Account / Source chips: bordered, muted text, truncated with an ellipsis), then the description.
- Alternating: centre spine, cards 396px wide alternating left and right (staggered so they never overlap), each card also shows its date and time; coloured connector from spine to card; day pills on the spine.
- Swimlanes: one 44px lane per tactic used (ATT&CK order, alternate lanes tinted), lane label with dot and count, time axis with clean ticks (15 min to 30 days, at most about 7), dots at true time positions joined by a faint polyline in event order, sequence number above each dot (below if crowded), an SVG <title> tooltip per dot, and a numbered two-column key below.
- ATT&CK board: one column per tactic used, up to 5 per row, 4px coloured top bar, tactic name and count, cards in time order with a numbered ring badge, date and time, technique and Host / Account / Source lines.

CHECK
Typing "T1566.002 Spearphishing Link" with no tactic selects Initial Access; the chart is coloured by tactic; all four views render and export to PNG; the chosen view survives a reload.

## STEP 09: IOC register and CSV export

STEP 09: IOC register. Return code blocks per marker.

@@JS-METRICS (add) statTile(num, label, sub, level) helper returning the .stat markup (used by register panels and the report).

@@JS-CONFIG-CASE: IOC_TYPES ([{value, label}]) and IOC_CONFIDENCE come from the question bank (step 02); do not redefine them.

@@JS-REGISTER-HELPERS (add)
- refang(s): trim; leading hxxp to http (keep case); [.] (.) {.} [dot] to "."; [:] to ":"; [@] [at] to "@"; [/] to "/".
- defang(type, v): ip and domain: dots to [.]; url: leading http to hxxp and dots to [.]; email: @ to [@] and dots to [.]; others unchanged.
- detectIocType(v) on the refanged value: 32/40/64 hex = md5/sha1/sha256; IPv4 dotted quad or IPv6 (hex and colons, more than two parts) = ip; scheme:// = url; x@y.z = email; ends with a common file extension (exe, dll, ps1, psm1, bat, cmd, js, jse, vbs, vbe, hta, lnk, msi, iso, img, zip, 7z, rar, gz, tar, docm, xlsm, doc, xls, ppt, pdf, txt, dat, tmp, scr, sys, bin, py, sh, jar) or contains a slash or backslash = filename; else a domain pattern = domain; else ''.
- normalizeIoc(item): refang; lowercase for domain, email and hashes; validate: hashes exact hex length ("SHA256 must be 64 hexadecimal characters."), IPv4 octets 0 to 255 or valid IPv6 ("Not a valid IPv4 or IPv6 address."), email ("Not a valid email address."), URL with scheme ("URL must include a scheme, e.g. https://"), domain ("Not a valid domain name."), last seen not before first seen ("Last seen is before first seen."). Returns {item} or {error}.
- mergeIoc(a, b): earliest first seen, latest last seen, highest confidence (High > Medium > Low), context lines combined without duplicates.
- csvCell(value, guard): quote when containing comma, quote or newline (double the quotes); when guard is true and the text starts with = + - @ tab or CR, prefix an apostrophe.
- exportIocCSV(rec, defanged): header type,value,confidence,first_seen_local,first_seen_utc,last_seen_local,last_seen_utc,context,case; rows sorted like the register; value raw or defanged; guard every cell except the value column; CRLF; no BOM; file "ir-iocs-raw-<slug>-<date>.csv" or "ir-iocs-defanged-..."; toast "Exported N IOCs (raw)." / "(defanged)".

@@JS-REGISTERS: entry iocs
tab "IOCs", title "Indicators of compromise", singular "IOC", intro "Paste values as-is: defanged input such as hxxp or [.] is converted back, the type is detected automatically, and duplicates are merged into the existing entry."
fields: value (required, wide, placeholder "IP, domain, URL, email, hash or file name", onChange: set the type select to detectIocType(value) unless the user picked a type manually); type (select, required); confidence (select, default Medium); firstSeen (datetime); lastSeen (datetime); context (textarea, wide, placeholder "Where it was seen and what it is, e.g. C2 beacon from WS042, Cobalt Strike").
normalize normalizeIoc; dedupeKey "type|value"; merge mergeIoc.
sort by IOC_TYPES order then value. columns: Type, Value (mono, exportText defanged), Confidence, First seen, Last seen, Context (pre).
toolbar: "CSV (raw, for EDR / SIEM)" and "CSV (defanged, for sharing)".
panel: tiles "Total IOCs" and one per type that has entries; or "No IOCs recorded yet."
Track the manual type choice with a data attribute on the type select (set on its change event, cleared on form reset, set when editing).

CHECK
"hxxps://evil[.]example[.]com/x" saves as https://evil.example.com/x (URL). Adding 185.220.101[.]45 twice merges into one entry. 999.1.1.1 is rejected. Raw CSV has 185.220.101.45, defanged CSV has 185[.]220[.]101[.]45.

## STEP 10: Affected assets register

STEP 10: Assets register (hosts and accounts). Return code blocks per marker.

@@JS-CONFIG-CASE (add) ASSET_KINDS: host "Host", account "Account". ASSET_STATUSES ([{value, label, color}]) comes from the question bank (step 02); do not redefine it.
@@JS-METRICS (add) assetStats(rec) => { host: counts per status + total + compromised, account: same, privileged }. Compromised = confirmed + contained + remediated (suspected does not count). privileged = accounts with privileged "Yes" and status not suspected.

@@JS-REGISTERS: entry assets
tab "Assets", title "Affected hosts and accounts", singular "asset", intro "Hosts and accounts in scope. Confirmed, contained and remediated all count as compromised; suspected does not."
fields: kind (Type, select, required, default host); name (required, placeholder "Hostname, or account (UPN / DOMAIN\user)"); identifier (placeholder "IP address, SID or other identifier"); role (label "Role / description", placeholder "e.g. Domain controller, finance user"); privileged (label "Privileged?", select Yes, No, Unknown); status (select, required, default suspected); notes (textarea, wide).
dedupeKey "kind|lowercase name" with no merge (duplicates are blocked).
sort by kind, then status order, then name. columns: Type, Name (mono), Identifier (mono), Role, Privileged, Status (tint badge), Notes (pre).
tabBadge "compromised/total" ('' when empty).
panel: tiles Hosts compromised (sub "N suspected", danger when above 0), Accounts compromised (same), Privileged accounts compromised (danger when above 0), Contained, Remediated; then a two-column area with a small table (rows Hosts and Accounts, columns per status and Total) and the line "Scoping estimate from the questionnaire: X systems, Y user accounts." from answers affected_systems_count and affected_users_count ("?" for a missing one; "Scoping estimate: not recorded in the questionnaire." when both are missing).
CSS (@@CSS-REGISTERS): .panel-cols (grid auto-fit minmax(240px, 1fr), gap 16px, margin-top 14px); .mini-table (collapsed, 0.88rem, cells padding 4px 14px 4px 0 with bottom border; thead muted 0.78rem); .mini-h (0.85rem muted).

CHECK
Adding DC01 then dc01 as hosts is blocked; tiles and the table match the entries; the Incident timeline host field now suggests asset hosts.

## STEP 11: Time log (hours)

STEP 11: Time log register with an optional hours cap. Return code blocks per marker.

@@JS-CONFIG-CASE (add) DEFAULT_BUDGET_WARN_PCT = 80.
@@JS-METRICS (add)
- entryMinutes(e) = Number(e.minutes) or, for older entries, Math.round(Number(e.hours) * 60).
- fmtMins(m): 95 => "1h 35m", 45 => "45m", 120 => "2h". fmtHours(h) = fmtMins(h * 60). fmtH(n) rounds to 2 decimals without trailing zeros (used for the cap).
- hoursInfo(rec) => { used (hours, from the sum of entryMinutes / 60), cap, pct, warnPct, level: '' | 'warn' | 'danger' } (danger at 100% or more, warn at warnPct or more, '' when no cap).
- normalizeRecord: convert older entries that have hours but no minutes to minutes (and drop the hours field).

@@JS-REGISTERS: entry hours
tab "Hours", title "Time log", singular "entry", intro "Each time you work on the case, log the date and the minutes spent. Totals show in hours and minutes. Optionally set an hours cap (e.g. the insurer panel limit) to get a warning as you approach it."
fields (only these two): date (required, default today); minutes (label "Time spent (minutes)", number, step 1, required, placeholder "e.g. 45").
normalize: minutes between 1 and 1440, rounded to whole minutes ("Time spent must be between 1 and 1440 minutes.").
sort by date newest first. columns: Date ("07 Oct 2026"), Time spent (fmtMins, right-aligned).
tabBadge: '' when nothing logged and no cap; "11h 30m / 10h" with a cap or "11h 30m" without; warn = level.
panel: inputs "Hours cap" (#budgetCap, min 0, step 0.5, placeholder "No cap") and "Warn at (% of cap)" (#budgetWarn, 1 to 100); then div#hoursMeter. wirePanel: on input update rec.budget, markDirty(), refresh only #hoursMeter and the tabs (do not re-render the inputs).
hoursMeterHTML(rec): with a cap: 12px meter (.meter, green fill; .warn and .danger variants) and text "11h 30m of 10h used (115%). 1h 30m over cap." (over cap in danger) or "... 2h 15m remaining."; without a cap: "11h 30m logged. No cap set." No per-person or per-activity breakdown.
afterChange(rec, before): toast "Time at 85% of the 10h cap." (warn) when crossing the warning level and "Hours cap exceeded: 11h 30m of 10h used." (error) when crossing 100%.
CSS: .budget-row (flex wrap, gap 14px, align end; labels grid gap 4px 600 0.88rem; inputs width 150px); .meter (12px pill, surface-3, margin 14px 0 6px; span success, width transition; .warn span warn; .danger span danger); .danger-text.

CHECK
With a 10h cap, logging 360 then 150 minutes warns at 85%; 180 more warns that the cap is exceeded; 0 or 2000 minutes is rejected; totals read like "11h 30m".

## STEP 12: JSON export / import and Markdown report

STEP 12: Exports and import. Return code blocks per marker and replace the temporary "Arrives in step 12" handlers.

@@JS-EXPORT
- buildExport(records): JSON string, 2-space indent: { schemaVersion: 3, app: 'ir-scoping', appVersion: '3.0.0', exportedAt, count, incidents }.
- markExported(ids): chained on state.saveChain; for each id read from DB, set lastExportedAt = now WITHOUT changing updatedAt, put back, upsertLocal; also set it on state.current; then updateHeader and renderList when on home.
- exportIncidentsJSON(records, filename): flushSave, re-read each record from the DB, download, markExported, toast "Exported N incident(s) to JSON.".
- exportAllJSON(): all records, file "ir-scoping-all-<date>.json" (toast "Nothing to export yet." when empty).
- colExport(column, item, rec) = exportText or text.
- toMarkdown(rec): "# IR Case Report: <title>", bullets Client, Incident type (caseTypesLabel), Phase, Incident timezone ("<tz or Not set> (date/times are local to this zone, UTC in brackets)"), Created, Last updated, Questions answered "X of Y", Record ID in backticks. Then "## <section>" for each questionnaire section with bold label lines (two trailing spaces) and answers or "_Not answered_" (hidden conditional questions omitted; multi-line answers keep line breaks). Then "## <tab>" for each non-empty register in REGISTER_ORDER: one bullet per item made of "**Column:** value" parts joined by " | " (IOCs defanged via exportText); the Hours section starts with "11h 30m logged against a cap of 10h (115%)." Footer "***" and "_Generated <date> by IR Scoping v3.0.0 (schema 3)._".
- exportMarkdown(rec): flush, re-read, download "ir-scoping-<slug>-<date>.md" (text/markdown), toast.
- sanitizeRegister(key, arr): keep only defined fields; numbers coerced (drop non-finite); other values must be strings (numbers and booleans converted); datetimes must match YYYY-MM-DDTHH:MM (cut to 16 chars); dates must match YYYY-MM-DD; drop items missing required fields; keep valid createdAt/updatedAt; returns {items, dropped}.
- sanitizeRecord(r, idx): errors for non-objects, missing id or incidentType, non-object answers; keep string, number, boolean or string-array answers; build the record, sanitise every register, normalizeRecord; warnings for unknown incident type, dropped answers and dropped register entries.
- validateImport(data): fatal if not an object, schemaVersion not a number, or incidents not an array; warning when schemaVersion is newer than 3; duplicate ids within the file keep the later one with a warning. Older schema 1 and 2 files must import (missing registers become empty, phase from status).
- mergeRecords(existing, incoming): the newer (by updatedAt) wins on top-level fields; answers combined (newer wins on conflicts); earliest createdAt; updatedAt = now; keep the local lastExportedAt; each register combined by item id (newer wins), then duplicate IOCs merged with mergeIoc; normalizeRecord.
- handleImportFile(file): parse errors and fatal or empty results show an "Import failed" modal listing messages. Otherwise a modal "Import incidents": counts, notes (skipped and warnings), and when ids already exist a radio choice "Merge" (default; "Combine answers and register entries. Where both have the same item, the more recently updated version wins.") or "Skip" ("Leave existing incidents untouched; only import new ones."). Apply with DB.putMany; toast "Import complete: X added, Y merged, Z skipped, N invalid."; refresh home.
- #importFile change handler: read the file, reset the input value so the same file can be imported again.
Wire: home "Export all", row JSON and Markdown buttons, and the case header "Export JSON" and "Export Markdown".

CHECK
Export one case and all cases; re-import with Merge creates no duplicates; a file with schemaVersion 1 and one incident {id, title, incidentType: 'malware', status: 'complete', answers: {}} imports as phase Closed; a broken file shows a clear error.

## STEP 13: Case phases, full search, backup reminder

STEP 13: Home screen upgrades. Return code blocks per marker and replaced functions.

@@JS-CONFIG-CASE (add) BACKUP_WARN_DAYS = 3.
@@JS-METRICS (add)
- relTime(ms): "just now", "Xm ago", "Xh ago", "Xd ago".
- backupInfo(rec): changedSince = never exported or updatedAt later than lastExportedAt; reference = lastExportedAt or createdAt; stale = changedSince and reference older than BACKUP_WARN_DAYS days; text "Last JSON export 2d ago" (+ ", changed since") or "Never exported to JSON".

REPLACE FUNCTION renderList:
- #backupBanner: when any case is stale, a .notice.warn "Backup reminder: N case(s) have changes not exported to JSON in over 3 days." with button #bkExport "Export all now" (calls exportAllJSON).
- #phaseFilter chips: All, Open cases (not completed or closed), then each phase, each with a count over all cases; clicking sets state.phaseFilter and re-renders; aria-pressed on the active chip.
- Filter by phase, then search with matchRecord; sort newest first; "N of M" counter.
- Keep the table columns from step 03 (Case ID, Incident type, Customer, Severity, Case logged, actions); do not add phase, flags or date columns to the table. When a search match was inside the case, show a line under the Case ID: "<where>: ...text with <mark>match</mark>..." (40 characters either side).
New helpers (@@JS-HOME):
- searchFields(rec): list of {where, text}: every visible non-bound question answer (formatAnswer, labelled with the question label) and every field of every register item (select values as labels, labelled with the register tab name).
- matchRecord(rec, term): search the term and its refanged form, case-insensitive; a match in title, Case ID, customer, type label, geolocation, severity or phase label returns {where: null}; otherwise the first field match with its index; null when no match.

REPLACE FUNCTION updateHeader: also fill #backupChip with backupInfo text ("Backup due: " prefix and .warn when stale).

CHECK
Phase chips filter and count correctly; searching adm_jsmith, evil[.]example, T1021 or an IOC value finds the case and shows where; a case created over 3 days ago and never exported shows "Backup due" and the banner; "Export all now" clears it without changing the case's last updated time.

## STEP 14: Print-ready report

STEP 14: Report tab and print styles. Return code blocks per marker.

@@JS-REPORT
renderReport(): renderShell('report', ...) with a toolbar (.report-toolbar): muted text "Print-ready view of the whole case. Use Print / Save as PDF and choose "Save as PDF" as the destination. IOCs are defanged." and primary button "Print / Save as PDF" (flushSave then window.print()); then article.report with reportHTML(rec).
reportHTML(rec):
- Header: kicker "INCIDENT RESPONSE CASE REPORT"; h1 title; metadata list: Client, Incident type, Phase, Timezone ("<tz> (local times shown, UTC in brackets)" or "Not set"), Created, Last updated, Generated, Record ID.
- "Key figures" stat tiles: Hosts compromised (sub "N suspected"), Accounts compromised, Privileged accounts compromised, IOCs, Incident timeline events, Time logged ("11h 30m", sub "of 10h cap (115%)" or "No cap set"), Questions answered ("X/Y").
- "Scoping questionnaire": answered questions only, h3 per section and a definition list; then "N unanswered questions omitted."
- One section per register in REGISTER_ORDER rendered as a table (headers = column labels; cells use exportText if present, else html, else escaped text). Hours starts with "11h 30m logged against a cap of 10h (115%).". Empty registers show "None recorded.".
Make sure refreshTabs shows the Report tab and openTab routes to it.

@@CSS-REPORT
.report-toolbar (flex wrap space-between, gap 12px, margin-bottom 14px). .report: override the theme tokens to the light values (surface #ffffff, surface-2 #f6f8fb, surface-3 #e9eef5, border #d3dbe6, text #17202b, muted #5b6878, accent #1d64d8, warn #a5710a, danger #c7323f, success #1e8a55), color-scheme light, white background, radius 12px, padding 36px 40px, max-width 1040px, centred. .rep-kicker (uppercase, letter-spacing 0.8px, 0.75rem 700 accent). h1 1.6rem. .rep-meta (grid max-content 1fr, gap 3px 18px, 0.9rem; dt muted). .rep-sec (margin-top 28px; h2 1.15rem with a 2px solid text-colour bottom border; h3 0.98rem). .rep-table (full width, collapsed, 0.84rem; cells padding 6px 8px with bottom border, top aligned; th surface-2, 0.72rem uppercase muted; td.pre pre-wrap). .rep-qa (grid minmax(180px, 36%) 1fr, 0.88rem, dotted row borders, dt muted, dd pre-wrap). At 700px: smaller padding and stacked Q/A.

@@CSS-PRINT
@media print: @page margin 14mm; force the light token values on :root and [data-theme]; print-color-adjust exact; white body, 12px; hide .topbar, .banner, .tabs, .inc-head, .report-toolbar, .app-foot, .toasts, all .btn, .wiz-foot and .sec-nav; main without padding or max-width; .report without padding, radius or max-width; .stat-grid 4 columns; avoid breaks inside table rows, Q/A pairs and stat tiles; avoid breaks after h2 and h3; table header rows repeat on every page.

CHECK
The Report tab looks like a clean white document in both themes. Print preview shows only the report, IOCs defanged, tables continuing across pages with repeated headers.

## STEP 15: Analytics screen

STEP 15: Analytics screen. Return code blocks per marker (put the JS under @@JS-REPORT, after the report code, and the CSS under @@CSS-REPORT).

PURPOSE
Month-on-month view across all cases: how many cases, which severities, which incident types. Opened from a new "Analytics" button in the home header (before "Import JSON"); "All incidents" goes back.

COUNTING
caseMonth(rec): "YYYY-MM" from answers.case_logged, else from createdAt. analyticsMonths(range, cases): a continuous list of months (empty months included) for the selected range: Last 6 months, Last 12 months (default, kept in state.analyticsRange), This year, All time (first case month to the later of now and the last case month).

COLOURS (validated categorical palette; never generate more hues)
CSS tokens on .viz. Dark (default): s1 #3987e5, s2 #d95926, s3 #199e70, s4 #c98500, s5 #d55181, s6 #008300, s7 #9085e9, s-other #5f6570. Light ([data-theme="light"] .viz): s1 #2a78d6, s2 #eb6834, s3 #1baf7a, s4 #eda100, s5 #e87ba4, s6 #008300, s7 #4a3aa7, s-other #b0aea6.
Severities take slots 1 to 5 in SEVERITIES order, "Not set" takes s-other. Incident types: the 7 types with the most cases ALL TIME take slots 1 to 7 (so a date-range change never repaints a type); the rest fold into "All other types" (s-other, legend shows how many types and lists them on hover). Text never uses series colours.

LAYOUT (top to bottom)
1. Title "Analytics" with the counting rule as a muted subtitle, and the range chips (same .pf chip style as the home phase filter) in one row above everything they scope.
2. Stat tiles: Cases in period (sub "Nov 2025 to Oct 2026"), Cases in <this month> (sub "+N vs <last month>", no colour), Most common severity (sub "N of M cases"), Most common incident type (value = count, sub = type).
3. Card "Cases per month by severity": legend (10px rounded swatch + label), stacked column chart, then <details> "View as table" (Month, one column per series, Total).
4. Card "Cases per month by incident type": same pattern.
5. Card "Cases by incident type in this period": horizontal bars, one series in s1, sorted by count, label left, value at the bar tip, 14px bars with a 4px rounded end, square at the start.
Empty period: a card "No cases in this period" with a hint.

STACKED COLUMN CHART (SVG, width = container width, min 320, height 280; margins left 40, right 12, top 22, bottom 30)
- Clean y ticks (1, 2 or 5 x 10^n, about 4 ticks), solid 1px gridlines in the border token, baseline in muted, tick labels 11px muted tabular figures.
- Columns at most 24px wide (60% of the band), segments stacked bottom-up with a 2px gap between segments, square at the baseline, 4px rounded top on the top segment only. Month total above each column (11px, 600, text colour). X labels "Oct 26", thinned so they never overlap.
- One transparent hit target per month covering the full band (tabindex 0, aria-label "Oct 2026: 13 cases"). Hover or focus highlights the band (surface-2) and shows one tooltip with the total and month, then EVERY series in legend order (short coloured line key, value strong, label muted; zero rows dimmed). Build tooltip, legend and table content with textContent, not innerHTML. Place the tooltip beside the column (right if it fits, else left).
- Re-render on window resize (debounced) while the Analytics screen is open.

CHECK
With cases across several months: columns and totals match "View as table"; tooltips list every series; switching ranges keeps each type's colour; both themes readable; no horizontal scrolling at 400px.

## STEP 16: Incident types screen

STEP 16: Incident types screen. Return code blocks per marker (put the JS under @@JS-REPORT, after the Analytics code, and the CSS under @@CSS-REPORT).

PURPOSE
A read-only reference of every incident type and its questions. Opened from an "Incident types" button in the home header (before "Analytics"); "All incidents" goes back.

BUILD
- QTYPE_LABELS: text Text, textarea Long text, number Number, date Date, time Time, datetime Date and time, select Dropdown, multiselect Checkboxes, yesno Yes / No, timezone Timezone.
- renderIncidentTypes(): flushSave, state.view 'types', clear current case; title "Incident types", muted subtitle "<N> incident types, <M> type-specific questions. Open a type to see its sections and questions. The common sections (Case summary, Incident Details and so on) apply to every type."; buttons "Expand all" (toggles to "Collapse all", opens / closes every card) and "All incidents".
- One <details class="card it-type"> per INCIDENT_TYPES entry. Summary: label (650 weight), id in <code> (muted, 0.8rem), "N sections, N questions" (muted small).
- Body: per section a block with a top border: h3 title, muted description, then an <ol> of questions. Each: bold label, a .type-more pill with QTYPE_LABELS[type], "(conditional)" muted when it has showIf, the Ask line (same .ask / .ask-tag style as the wizard, from q.ask), and options joined with " · " (muted small).
- document.title "Incident types - IR Scoping v3".

CHECK
Every type is listed with correct counts; new types added to the config appear without other changes; no horizontal scrolling at 400px.

## STEP 17: Report checklist

STEP 17: Report checklist tab. Return code blocks per marker (config under @@JS-CONFIG-CASE, JS under @@JS-REPORT before renderReport, CSS under @@CSS-REPORT).

PURPOSE
Yes / no / N/A checks to confirm the report is complete before it goes out. Stored in rec.checks = { checkId: 'Yes' | 'No' | 'N/A' }.

CONFIG
CHECK_ANSWERS = ['Yes', 'No', 'N/A'] under @@JS-CONFIG-CASE. REPORT_CHECKS_COMMON and REPORT_CHECKS already come from the question bank (step 02); do not retype the checks.

DATA
newRecord adds checks: {}. normalizeRecord: checks must be a plain object; drop values not in CHECK_ANSWERS. sanitizeRecord copies r.checks when it is an object. mergeRecords: checks = Object.assign({}, older.checks, newer.checks).

BUILD
- checkGroups(rec): [{label "All incidents", items REPORT_CHECKS_COMMON}, then one group per caseTypes(rec) entry with REPORT_CHECKS[t] (label typeLabel(t))], skipping empty groups.
- checkStats(rec): total, yes, na, no, open, gaps (items answered No), pct = round(yes / (total - na) * 100), 0 when nothing applies.
- Tab "Report checklist" (id 'checks') before Report; badge "<pct>%", warn (amber) when any answer is No. openTab('checks') calls renderChecks().
- renderChecks(): a summary card (#chkHead: big "<pct>% complete", "Yes n · No n · N/A n · Not answered n. Completeness is Yes divided by all checks except N/A.", and a red-tinted "Gaps (answered No)" list), a muted intro line, then one card per group with each check as a row: label on the left, a .seg radio group Yes / No / N/A (No checked = danger background, N/A checked = surface-3) and a "Clear" link (space reserved when hidden). Changing or clearing updates rec.checks, the summary card and the tab badge, then markDirty().
- Report tab: inside .report-toolbar (so it never prints) a full-width .chk-note: "Report checklist: <pct>% complete." then "<n> gap(s): <labels joined by '; '>", or "<n> checks not answered yet.", or "No gaps."
- toMarkdown: before the footer, "## Report checklist (internal)", a line with the percentage and counts, then per group a bold group label and "- <label> **<answer or Not answered>**" lines.

CHECK
Answering Yes, No and N/A updates the percentage correctly; gaps list the No items; answers survive reload, JSON export / import and appear in the Markdown export; no horizontal scrolling at 400px.

## STEP 18: Final review against acceptance tests

STEP 18: Review the whole current v3.html (I will paste it if you no longer have it) against these acceptance tests. For each test, say pass or fail. For every fail, give the fix as a REPLACE FUNCTION or a marker block. Do not rewrite unrelated code.

1. Opens with no console errors (missing favicon is fine).
2. New Ransomware case with Case ID "IR-TEST-1" gets the title "IR-TEST-1" (not combined with other values) and opens on Case summary.
3. Answering Yes to "Any related or prior incidents in the last 12 months?" reveals the prior incident details question without losing focus; reload keeps the answer and section.
4. Europe/London 2026-07-01 09:30 shows 08:30 UTC; 2026-12-01 09:30 shows 09:30 UTC; America/New_York 2026-10-07 09:30 shows 13:30 UTC.
5. Case timeline events are date-only: the table shows "07 Oct 2026", and the chart shows day gaps ("+3d") and "same day".
6. IOC refanging, auto type, merging of duplicates, rejection of 999.1.1.1, raw versus defanged CSV.
7. Duplicate asset names (any case) are blocked; compromised and privileged counts are right.
8. Technique T1566.002 auto-selects Initial Access; host suggestions come from assets; PNG exports are non-empty.
9. Hours warning at 85% and cap exceeded toasts; 30h rejected.
10. Phase changes persist; phase chips filter and count; Open cases excludes closed.
11. Search finds text inside answers and every register, including defanged terms.
12. Backup reminder appears for stale cases and clears after export without changing last updated.
13. JSON export and re-import with Merge creates no duplicates; schema 1 files import; invalid entries are reported.
14. Markdown includes every section, non-empty registers, defanged IOCs and the hours summary.
15. Report prints cleanly in light colours.
16. Theme toggle changes everything, including the on-screen chart, and is remembered.
17. Works at 400px width and with the keyboard only; focus is always visible.
18. Every customer-facing question shows its ASK spoken prompt under the heading; internal fields (incident title, Case ID, case logged date, severity) show none; no [config] warnings in the console.
20. Home > Incident types lists every incident type in json/questionnaire/lists.json with the section, question and report-check counts from its JSON file.
19. Analytics opens from the home screen; monthly columns, totals and the table views agree; each incident type keeps its colour across date ranges.
Also confirm: no em dash characters, no alert/confirm/prompt, all user text escaped, no network requests.
Finish with a short list of assumptions and how to add a new incident type (a new json/incident-types/<id>.json, its id in lists.json incidentTypeOrder, then UPDATE), a new register field and a new IOC type (lists.json iocTypes, then UPDATE).

## UPDATE: Update the question bank after editing JSON (use any time)

UPDATE: Update the question bank from edited JSON files. Return only the changed parts of the question-bank block.

I have edited the attached JSON file(s). Update the <script type="application/json" id="question-bank"> block in v3.html to match them exactly:
- json/questionnaire/lists.json -> "lists"; json/questionnaire/common-sections.json -> "common"; json/questionnaire/closing-sections.json -> "closing"; json/questionnaire/report-checks-common.json -> "reportChecksCommon"; json/incident-types/<id>.json -> "types"."<id>".
- Remove the "_notes" key. Copy everything else exactly, compact JSON, one top-level key (or one type) per line. Write "</" as "<\/".
- A new incident type needs its file under "types" AND its id in lists.incidentTypeOrder. A removed type: delete it from both.
- Do not change any JavaScript unless a file uses a new "optionsFrom" name (then add it to OPTION_SOURCES) or a new question property the code does not support (then tell me first).

Rules: never rename an existing id (question, section, check, phase, list value); question ids must stay unique across all files; showIf must point at an existing question; no em dash characters. Warn me about any of these problems instead of guessing.

Reply with: (1) what changed (added, removed, edited), (2) the replaced lines of the question-bank block, (3) a short test list.
